core.controller('Topnavbar', function($scope, $state, $rootScope) {

	// $scope.checkState = function(){
	// 	console.log('inside top navbar');
	// 	console.log($state.current.name, 'current state');
	// 	if($state.current.name === 'home' || $state.current.name === 'story' || $state.current.name === 'settings' || $state.current.name === 'createStory' )return true;
	// }

	$scope.save = function(){
		console.log("save ran")
		$rootScope.$broadcast('saveImage')
	}

});