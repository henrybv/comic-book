// core.directive('navbarHome', function() {
// 	return {
// 		restrict: 'E',
// 		templateUrl: 'js/navbar/navbar.main/navbar.main.home.html'
// 	}
// });