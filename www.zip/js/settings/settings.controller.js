core.controller('SettingsCtrl', function($scope, $localStorage) {
	$scope.user = $localStorage.user;
	// $scope.logout = 
});