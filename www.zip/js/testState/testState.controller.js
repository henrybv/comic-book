// core.controller('testStateCtrl', function($scope, getAddons) {
	
//     $scope.testFunc = function() {
//         console.log("This works")
//     }

//     $scope.allAddons = getAddons
    
// });