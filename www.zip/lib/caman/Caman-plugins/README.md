# CamanJS Plugins

[CamanJS](https://github.com/meltingice/CamanJS) is an image manipulation library written in Javascript. This repository contains all plugins and features that are not a part of the core library.

## Contributing

Anyone is encouraged to contribute bug fixes or new features. The proper way to add a new feature is:

1. Fork this repository.
2. Create a new branch for the feature/plugin you're adding.
3. Commit your changes.
4. Send a pull request!
